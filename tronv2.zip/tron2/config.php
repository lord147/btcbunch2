<?php


//useragent

$user = "xxxxxxxx";


//https://claimtrx.com
//cookie

$trxking = "xxxxxxx";




//https://trxking.xyz
//cookie

$claimtrx = "xxxxxx";



