<?php


$wallet = "xxxxx";


$user_agent = "xxx";

$cookie = "xxxx";



//NAYAN// .....[Termux Xplorer]