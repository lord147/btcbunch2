<?php

// ISI SEMUA DATA DENGAN BENAR
// JANGAN SKIP VIDEO SUPAYA GAK GAGAL

//user-agent
$user = "Mozilla/5.0 (Linux; Android 10; Infinix X692) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36";

//cookie
$cookie = "a=11ZmySTsNXTKVsLnlt5eCdJrO8wWat6f; token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAYUJPcgFhQk9zgAGBAsAAIBbynTwquvu6B-r0m5HwDZKx8do5Ucu0gWXxHteUY2ccwQBGMEQCIEgdr1Ct2DEe6T6pV87AP1-coxv2ChI7j1IiKeZxL17oAiAXEsB78oRkl0xyIxYjFt_B37XL_1e4HLbPEyKDiOslyQ";


//url-target-claim
$webtarget = "http://uptocoin.tk/fp/faucet.php?address=DPLHnRoegKKNXeetQ5Qo8bzzJH6QUaGckh&currency=DOGE&key=f1c72d528df265988051b46c9b167f01";
