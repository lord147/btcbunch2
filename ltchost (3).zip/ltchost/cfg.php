<?php

$useragent = "xxxx";

$cookie = "xxxx";

//minimum autowithdraw min(1000 Satoshi)
$withdraw = "0.00001000";