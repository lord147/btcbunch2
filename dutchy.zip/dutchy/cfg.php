<?

//https://api-secure.solvemedia.com/papi/_challenge.js?k=rrwQxxxxx
$url_solvmedia="xxxxx";
//https://autofaucet.dutchycorp.space/
$user_agent="xxxxx";
$cookie="xxxxx";

