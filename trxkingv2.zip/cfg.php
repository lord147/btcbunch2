<?php

$useragent = "Mozilla/5.0 (Linux; Android 9; JAT-L29) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36";

$cookie = "_gid=GA1.2.2139677143.1631887541; dom3ic8zudi28v8lr6fgphwffqoz0j6c=e3bcb721-b8b2-4112-b6a7-0b3d1caeff73:3:1; csrf_cookie_name=c10589f0ae3b08c09d3e56c54779a56a; ci_session=e7dc1c196cbeab9736affa2c7d150e4ce21b8697; sb_main_a344467b4521bdefdf86b1cb6e25fc60=1; sb_count_a344467b4521bdefdf86b1cb6e25fc60=2; _data_pop=479-2-1632156287; _ga=GA1.2.67613912.1631887541; _gat_gtag_UA_201762265_3=1; pbpr0tpuw4isk85t8yg3jb2lj5vqf=residelikingminister.com; pop_delay_3777=1; _ga_RZYLV5PCX4=GS1.1.1632069562.8.1.1632069953.0; sb_delay_a344467b4521bdefdf86b1cb6e25fc60=1";