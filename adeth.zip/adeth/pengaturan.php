<?php

$useragent = "xxxx";

//ikuti cara ambil cookie di video

$ssid_eth = "xxxx";
