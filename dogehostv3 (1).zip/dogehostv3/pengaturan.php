<?php

$useragent = "xxxx";

$cookie = "xxxx";

//min wd 
$withdraw = "0.00001000";