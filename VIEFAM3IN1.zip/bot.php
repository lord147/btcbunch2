<?php

//color
$hijau = "\33[0;32m";
$hijau1 = "\33[32;1m";
$hijau2 = "\e[1;32m";
$biru = "\33[0;36m";
$biru1 = "\33[36;1m";
$biru2 = "\e[1;34m";
$merah = "\33[31;1m";
$merah2 = "\e[1;31m";
$putih2 = "\33[37;1m";
$putih1 = "\e[1;37m";
$hitam = "\33[30;1m";
$kuning = "\33[33;1m";
$kuning1 = "\33[1;33m";
$kuning2 = "\e[1;33m";
$cyan = "\e[0;36m";
$cyan1 = "\e[1;36m";
$ungu = "\e[0;35m";
$ungu2 = "\e[1;35m";
$abu =	"\e[0;33m";
$abu1 = "\e[0;37m";
$abu2 = "\e[1;30m";
include('cfg.php');
system('clear');

sleep(1);
echo$putih2."Loading Script ".$kuning2."[".$cyan1."0%".$kuning2."]\n\n";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."7%".$kuning2."]\n\n";
echo$abu2." ██╗   ██╗\n";
echo$abu2." ╚██╗ ██╔╝\n";    
echo$abu2."  ╚████╔╝\n";   
echo$abu2."   ╚██╔╝\n";    
echo$abu2."    ██║\n"; 
echo$abu2."    ╚═╝\n";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."33%".$kuning2."]\n\n";
echo$abu2." ██╗   ██╗███████╗███████╗\n";
echo$abu2." ╚██╗ ██╔╝╚══███╔╝╚══███╔╝\n";    
echo$abu2."  ╚████╔╝   ███╔╝   ███╔╝\n";   
echo$abu2."   ╚██╔╝   ███╔╝   ███╔╝\n";    
echo$abu2."    ██║   ███████╗███████╗\n"; 
echo$abu2."    ╚═╝   ╚══════╝╚══════╝\n";
sleep(1);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."66%".$kuning2."]\n\n";
echo$abu2." ██╗   ██╗███████╗███████╗███████╗\n";
echo$abu2." ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝\n";    
echo$abu2."  ╚████╔╝   ███╔╝   ███╔╝   ███╔╝\n";   
echo$abu2."   ╚██╔╝   ███╔╝   ███╔╝   ███╔╝\n";    
echo$abu2."    ██║   ███████╗███████╗███████╗\n"; 
echo$abu2."    ╚═╝   ╚══════╝╚══════╝╚══════╝\n";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."87%".$kuning2."]\n\n";
echo$abu2." ██╗   ██╗███████╗███████╗███████╗████████╗\n";
echo$abu2." ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝╚══██╔══╝\n";    
echo$abu2."  ╚████╔╝   ███╔╝   ███╔╝   ███╔╝    ██║\n";   
echo$abu2."   ╚██╔╝   ███╔╝   ███╔╝   ███╔╝     ██║\n";    
echo$abu2."    ██║   ███████╗███████╗███████╗   ██║\n"; 
echo$abu2."    ╚═╝   ╚══════╝╚══════╝╚══════╝   ╚═╝\n";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."96%".$kuning2."]\n\n";
echo$abu2." ██╗   ██╗███████╗███████╗███████╗████████╗██╗   ██╗\n";
echo$abu2." ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝╚══██╔══╝██║   ██║\n";    
echo$abu2."  ╚████╔╝   ███╔╝   ███╔╝   ███╔╝    ██║   ██║   ██║\n";   
echo$abu2."   ╚██╔╝   ███╔╝   ███╔╝   ███╔╝     ██║   ╚██╗ ██╔╝\n";    
echo$abu2."    ██║   ███████╗███████╗███████╗   ██║    ╚████╔╝\n"; 
echo$abu2."    ╚═╝   ╚══════╝╚══════╝╚══════╝   ╚═╝     ╚═══╝\n";
sleep(2);
system('clear');
echo$putih2."Loading Script ".$kuning2."[".$cyan1."99%".$kuning2."]\n\n";
echo$merah2." ██╗   ██╗███████╗███████╗███████╗████████╗██╗   ██╗\n";
echo$merah2." ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝╚══██╔══╝██║   ██║\n";    
echo$merah2."  ╚████╔╝   ███╔╝   ███╔╝   ███╔╝    ██║   ██║   ██║\n";   
echo$merah2."   ╚██╔╝   ███╔╝   ███╔╝   ███╔╝     ██║   ╚██╗ ██╔╝\n";    
echo$merah2."    ██║   ███████╗███████╗███████╗   ██║    ╚████╔╝\n"; 
echo$merah2."    ╚═╝   ╚══════╝╚══════╝╚══════╝   ╚═╝     ╚═══╝\n";
sleep(2);
system('clear');
echo$hijau2."✔ Script Loaded ".$kuning2."[".$cyan1."100%".$kuning2."]";
echo $banner = "

$merah2 ██╗   ██╗███████╗███████╗███████╗████████╗██╗   ██╗    
$merah2 ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝╚══██╔══╝██║   ██║    
 $merah ╚████╔╝   ███╔╝   ███╔╝   ███╔╝    ██║   ██║   ██║    
  $putih2 ╚██╔╝   ███╔╝   ███╔╝   ███╔╝     ██║   ╚██╗ ██╔╝    
  $putih2  ██║   ███████╗███████╗███████╗   ██║    ╚████╔╝ 
   $putih1 ╚═╝   ╚══════╝╚══════╝╚══════╝   ╚═╝     ╚═══╝\n\n";
sleep(2);
echo$kuning2."        PLEASE DO NOT SKIP THE TUTORIAL VIDEO!\n";
sleep(5);
system('clear');

//banner
echo $banner2 = "

$merah2 ██╗   ██╗███████╗███████╗███████╗████████╗██╗   ██╗    
$merah2 ╚██╗ ██╔╝╚══███╔╝╚══███╔╝╚══███╔╝╚══██╔══╝██║   ██║    
 $merah ╚████╔╝   ███╔╝   ███╔╝   ███╔╝    ██║   ██║   ██║    
  $putih2 ╚██╔╝   ███╔╝   ███╔╝   ███╔╝     ██║   ╚██╗ ██╔╝    
  $putih2  ██║   ███████╗███████╗███████╗   ██║    ╚████╔╝ 
   $putih1 ╚═╝   ╚══════╝╚══════╝╚══════╝   ╚═╝     ╚═══╝
$cyan1   <[ LETS MAKE OUR ZERO BITCOIN TO ONE BITCOIN! ]>\n";
echo$kuning2."       <[".$putih2."BOT AUTOFAUCET 3IN1 VIEFAUCET FAMILY".$kuning2."]>\n";
echo$cyan1."               ~ Script by : ".$kuning2."YzZz Tv ~\n";
echo$merah2." ≠=================================================≠\n";
sleep(2);
echo$kuning2." If this script work for you, ";
echo$merah2."[".$putih2."SUBSCRIBE".$merah2."]".$cyan1." YzZz Tv 😇\n";
sleep(3);
system('termux-open-url https://www.youtube.com/c/YzZzTv');
sleep(10);
echo$biru."/////////////💓".$putih2." Thanks for SUBSCRIBE! ".$biru."😘////////////\n";
sleep(2);
echo$hijau2." ==This script is FREE!, FREE to use, FREE to edit==\n";
echo$biru."////////////////////////////////////////////////////\n";
sleep(2);
echo$kuning2."Using a script to claiming faucet is very high risk!\n";
echo$kuning2."Please use with carefully! ".$merah2."DO WITH AT YOUR OWN RISK!\n";
sleep(2);
echo$kuning2."Using this script are mean you are agree to".$biru."/////////\n";
echo$kuning2."all above the risk!".$biru."/////////////////////////////////\n";
sleep(2);
echo$putih2."Type (capital) C then press ENTER if you want to".$biru."////\n";
echo$putih2."canceling the script".$biru."////////////////////////////////\n";
echo$cyan1."or Press ENTER to running this script".$biru."///////////////\n";
$agree = readline($putih2."Your answer => ".$kuning2);
sleep(2);
if($agree == "C"){
echo$merah2."Have a nice day!, the script stopped.\n";
sleep(2);
exit;
}else{
system('clear');
echo $banner2;
echo$kuning2."       <[".$putih2."BOT AUTOFAUCET 3IN1 VIEFAUCET FAMILY".$kuning2."]>\n";
echo$cyan1."               ~ Script by : ".$kuning2."YzZz Tv ~\n";
echo$merah2." ≠=================================================≠\n";
sleep(2);

function Get($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

function Post($url, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "./cookie/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "./cookie/cookie.txt");
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}

echo$hijau2."Autofaucet started!\n\n";
sleep(2);

while(true){

//1xbitcoins.com 180 sec
$url = "https://www.1xbitcoins.com/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_1xbitcoins];
$cfg = Get($url, $ua);
$one = explode('<h5 class="mb-0">',$cfg);
$two = explode(' toke',$one[1]);
$b = "$two[0]";

echo$putih2."1xbitcoins start balance : ".$b.$kuning2." You will get 1 coin\n";
sleep(3);

$url = "https://www.1xbitcoins.com/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_1xbitcoins];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$abu2." Auto 1xbitcoins ".$merah."[".$kuning2.$x.$merah."] ".$abu2."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://www.1xbitcoins.com/auto/verify";
$data = "token=$t";
$cfg = Post($link, $ua, $data);

$url = "https://www.1xbitcoins.com/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_1xbitcoins];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

sleep(3);

$url = "https://www.1xbitcoins.com/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_1xbitcoins];
$cfg2 = Get($url, $ua);
$one2 = explode('<h5 class="mb-0">',$cfg2);
$two2 = explode(' toke',$one2[1]);
$b2 = "$two2[0]";

echo $kuning2."√ Finish Claim in 1xbitcoins ".$putih2.":: Update Balance : {$hijau2}$b2\n";
sleep(2);


//cryptoaffiliates.store 120 sec
$url = "https://cryptoaffiliates.store/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_cryptoaf];
$cfg = Get($url, $ua);
$one = explode('<h4 class="mb-0">',$cfg);
$two = explode(' toke',$one[1]);
$b = "$two[0]";

echo$putih2."CryptoAffiliates start balance : ".$b.$kuning2." You will get 1 coin\n";
sleep(3);

$url = "https://cryptoaffiliates.store/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_cryptoaf];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$abu2." Auto CryptoAffiliates ".$merah."[".$kuning2.$x.$merah."] ".$abu2."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://cryptoaffiliates.store/auto/verify";
$data = "token=$t";
$cfg = Post($link, $ua, $data);

$url = "https://cryptoaffiliates.store/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_cryptoaf];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

sleep(3);

$url = "https://cryptoaffiliates.store/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_cryptoaf];
$cfg2 = Get($url, $ua);
$one2 = explode('<h4 class="mb-0">',$cfg2);
$two2 = explode(' toke',$one2[1]);
$b2 = "$two2[0]";

echo $kuning2."√ Finish Claim in CryptoAff  ".$putih2.":: Update Balance : {$hijau2}$b2\n";
sleep(2);

//auto.speedcoins.xyz 30 sec
$url = "https://auto.speedcoins.xyz/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_speedcoins];
$cfg = Get($url, $ua);
$one = explode('<h4 class="mb-0">',$cfg);
$two = explode('</h4>',$one[1]);
$b = "$two[0]";

echo$putih2."SpeedCoins start balance : ".$b.$kuning2." You will get 0.00045 USDT\n";
sleep(3);

$url = "https://auto.speedcoins.xyz/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_speedcoins];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

for($x=$tmr;$x>0;$x--){echo "\r \r";
echo$abu2." Auto SpeedCoins ".$merah."[".$kuning2.$x.$merah."] ".$abu2."seconds ☕🚬";
echo "\r \r";
sleep(1);}

$link = "https://auto.speedcoins.xyz/auto/verify";
$data = "token=$t";
$cfg = Post($link, $ua, $data);

$url = "https://auto.speedcoins.xyz/auto";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_speedcoins];
$cfg = Get($url, $ua);
$one = explode('name="token" value="', $cfg);
$two = explode('">', $one[1]);
$t = "$two[0]";
$one = explode('let timer = ', $cfg);
$two = explode(',', $one[1]);
$tmr = "$two[0]";

sleep(3);

$url = "https://auto.speedcoins.xyz/dashboard";
$ua = ["user-agent: ".$useragent,
"cookie: ".$c_speedcoins];
$cfg2 = Get($url, $ua);
$one2 = explode('<h4 class="mb-0">',$cfg2);
$two2 = explode('</h4>',$one2[1]);
$b2 = "$two2[0]";

echo $kuning2."√ Finish Claim in SpeedCoins ".$putih2.":: Update Balance : {$hijau2}$b2\n";
sleep(2);


}}