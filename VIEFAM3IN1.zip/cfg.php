<?php

$useragent = "xxxx";

$c_1xbitcoins = "xxxx";

$c_speedcoins = "xxxx";

$c_cryptoaf = "xxxx";