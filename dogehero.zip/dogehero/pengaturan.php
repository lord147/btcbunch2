<?php

//Jangan Sampe Ilang Tanda Petik ( " )

$ua = "xxxx";

$cookie = "xxxx";