<?php



$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36";



$ssid_ltc = "PHPSESSID=9m0co6ngfj48ohevqspk9744v6";

$ssid_dgb = "PHPSESSID=hiv22d42d8jm098dlelq8bcrp5";

$ssid_trx = "PHPSESSID=nh3fp9qdv36hbekgm1rg4d8p87";

$ssid_doge = "PHPSESSID=7voh0f2gafdbe0lghflkeivr02";

$ssid_btc = "PHPSESSID=pe54lp30aee5fo3tc5di8777t7";
