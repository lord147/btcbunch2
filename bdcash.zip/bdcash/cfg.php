<?php

$email="xxxxxxxx@gmail.com";

$hash="xxxxxxxx";

?>
