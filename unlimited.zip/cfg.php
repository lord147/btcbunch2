<?
//PERHATIKAN CARA ADMIN MENGISI DATA

$cookie = "xxxxx";
$user = "xxxx";