<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$user_agent = "Masukan User-Agent Disini";

$cookies = "Masukan Semua Cookie Disini";

