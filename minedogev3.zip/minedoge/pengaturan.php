<?php

$useragent = "xxxx";

$cookie = "xxxx";

//WD setiap mencapai berapa DOGE
$withdraw = "0.001";

//Collect profit setiap berapa detik
$tmr = "90";