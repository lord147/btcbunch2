<?

$url="xxxxx";
$user_agent="xxxxx";
$cookie="xxxxx";