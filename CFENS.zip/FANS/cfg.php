<?php

$useragent = "Mozilla/5.0 (Linux; Android 10; V2027) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36";

$cookie = "ci_session=6d512805274c9337e8325c37a18cc77e70534a48; csrf_cookie_name=c9bd3022f3e97cac2b410b21a900f6b5; _ga=GA1.2.144285198.1633999890; _gid=GA1.2.1347665586.1633999890; __viCookieActive=true";

$b = "10";