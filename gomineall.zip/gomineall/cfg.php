<?php

$useragent = "xxxx";

$ctrx = "xxxx";

$cdoge = "xxxx";

$cltc = "xxxx";

$czec = "xxxx";