<?php 

$cookie = "xxx";

$user_agent = "xxx";

?>