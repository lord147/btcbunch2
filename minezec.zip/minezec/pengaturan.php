<?php

$useragent = "xxxx";

$cookie = "xxxx";

//WD setiap mencapai berapa ZEC Mininal 0.00000010 ZEC/ 10 Satoshi ZEC
$withdraw = "0.00000010";

//Collect profit setiap berapa detik
$tmr = "90";