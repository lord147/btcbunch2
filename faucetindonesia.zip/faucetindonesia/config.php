<?php

//USER-AGENT
$user = "Mozilla/5.0 (Linux; Android 8.1.0; vivo 1811) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36";

//COOKIE DASHBOARD
$cookie = "_rce=ID;dom3ic8zudi28v8lr6fgphwffqoz0j6c=e57a8822-7947-4850-b6c6-4d6336985c1e%3A1%3A1;acceptCookies=true;sb_main_becf7aed44ebf6a8eb085ccac6e4df72=1;sb_count_becf7aed44ebf6a8eb085ccac6e4df72=4;_pk_id.1.ca13=5fdd919d04a8475f.1633416483.;_pk_ses.1.ca13=1;AUTH_SYSTEM=b4367ae2f3c76586e8ea003ebac7a18b";
