<?php

$useragent = "xxxxxxxxx";



// 1 
$c_1xbitcoins = "xxxxxxx";


// 2
$c_speedcoins = "xxxxxxxxx";



// 3

$c_cryptoaf = "xxxxxxxxxx";





